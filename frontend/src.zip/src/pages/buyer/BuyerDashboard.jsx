import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search, ShoppingCart, User, Home, Package, Truck, CreditCard, ChevronDown, Plus, Minus, X,
  ChevronsRight, Loader2, CheckCircle, AlertCircle, MapPin, Edit, Sun, Moon, CheckSquare
} from 'lucide-react';

// Helper to get authentication token from localStorage
const getAuthToken = () => {
  return localStorage.getItem('buyer_token');
};

// Helper to get buyer user info from localStorage
const getBuyerUser = () => {
  const user = localStorage.getItem('buyer_user');
  try {
    return user ? JSON.parse(user) : null;
  } catch (e) {
    console.error("Failed to parse buyer_user from localStorage", e);
    return null;
  }
};

const BuyerDashboard = () => {
  const navigate = useNavigate();

  // **THEME STATE**
  const [isDarkMode, setIsDarkMode] = useState(
      localStorage.getItem('theme') === 'dark'
  );

  // **CART MODAL STATE**
  const [showCartModal, setShowCartModal] = useState(false);

  // **ORDER PROCESS STATES**
  const [currentOrderStep, setCurrentOrderStep] = useState('cart'); // 'cart', 'address-selection', 'confirmation'
  const [selectedAddressForOrder, setSelectedAddressForOrder] = useState(null);

  // **DATA STATES**
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [addresses, setAddresses] = useState([]);
  const [orders, setOrders] = useState([]);
  const [userProfile, setUserProfile] = useState(null);
  const [productQuantities, setProductQuantities] = useState({}); // Stores quantities for products in the product listing

  // **UI STATES**
  const [activeCategory, setActiveCategory] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [toast, setToast] = useState({ show: false, message: '', type: '' });
  const [currentView, setCurrentView] = useState('products'); // 'products', 'myOrders', 'address'
  const [requiresLogin, setRequiresLogin] = useState(false);

  // **LOADING STATES**
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [loadingCart, setLoadingCart] = useState(false);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [loadingAddresses, setLoadingAddresses] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);

  // **MAP STATES (for address management)**
  const [showMap, setShowMap] = useState(false);
  const [leafletLoaded, setLeafletLoaded] = useState(false);
  const mapRef = useRef(null);
  const leafletMapInstance = useRef(null);
  const leafletMarkerInstance = useRef(null);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    latitude: '',
    longitude: ''
  });

  // **ADDRESS EDITING STATES**
  const [editingAddressId, setEditingAddressId] = useState(null);
  const [isDefault, setIsDefault] = useState(false);

  // **THEME EFFECT**
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const showToast = (message, type = 'success') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message, type: '' }), 4000);
  };

  // Load Leaflet CSS and JS dynamically
  useEffect(() => {
    if (!document.querySelector('link[href*="leaflet.css"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      link.integrity = 'sha256-p4NxAo9TxxGgCCSgPropynS9kSqyFastalU8PkUWfmkz/tdwG62/rqQkFFMlK/RTgsqT4A2jW/CntN9C7A5VfCg==';
      link.crossOrigin = '';
      document.head.appendChild(link);
    }

    if (!window.L && !document.querySelector('script[src*="leaflet.js"]')) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
      script.crossOrigin = '';
      script.async = true;
      script.onload = () => setLeafletLoaded(true);
      script.onerror = () => {
        showToast("Failed to load map library script.", "error");
        setLeafletLoaded(false);
      };
      document.head.appendChild(script);
    } else if (window.L) {
      setLeafletLoaded(true);
    }
  }, []);

  // Reverse geocoding function
  const reverseGeocodeNominatim = async (lat, lon) => {
    try {
      const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`,
          {
            headers: {
              'User-Agent': 'GrocerySellerRegistrationApp/1.0 (your.email@example.com)'
            }
          }
      );

      if (response.ok) {
        const data = await response.json();
        return data.display_name || `Lat: ${lat.toFixed(6)}, Lng: ${lon.toFixed(6)}`;
      } else {
        console.error("Nominatim reverse geocoding failed:", response.status, response.statusText);
        showToast("Address lookup failed. Coordinates captured.", "error");
        return `Lat: ${lat.toFixed(6)}, Lng: ${lon.toFixed(6)}`;
      }
    } catch (error) {
      console.error("Nominatim reverse geocoding network error:", error);
      showToast("Network error during address lookup. Coordinates captured.", "error");
      return `Lat: ${lat.toFixed(6)}, Lng: ${lon.toFixed(6)}`;
    }
  };

  // Initialize Leaflet map
  const initializeLeafletMap = async () => {
    if (!leafletLoaded || !window.L || !mapRef.current) {
      console.warn("Leaflet library not loaded or mapRef not available.");
      return;
    }

    if (leafletMapInstance.current) {
      leafletMapInstance.current.remove();
      leafletMapInstance.current = null;
    }

    const defaultCenter = { lat: 20.5937, lng: 78.9629 };
    let initialLat = parseFloat(formData.latitude);
    let initialLng = parseFloat(formData.longitude);
    let center = (initialLat && initialLng && !isNaN(initialLat) && !isNaN(initialLng))
        ? [initialLat, initialLng]
        : [defaultCenter.lat, defaultCenter.lng];

    const map = window.L.map(mapRef.current).setView(center, 15);
    leafletMapInstance.current = map;

    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const marker = window.L.marker(center, { draggable: true }).addTo(map);
    leafletMarkerInstance.current = marker;

    const updateLocationAndAddress = async (latlng) => {
      setFormData(prev => ({
        ...prev,
        latitude: latlng.lat.toString(),
        longitude: latlng.lng.toString()
      }));
      const address = await reverseGeocodeNominatim(latlng.lat, latlng.lng);
      setFormData(prev => ({ ...prev, address: address }));
      showToast("Location selected from map!", "success");
    };

    await updateLocationAndAddress(marker.getLatLng());

    marker.on('dragend', async (event) => {
      await updateLocationAndAddress(event.target.getLatLng());
    });

    map.on('click', async (event) => {
      marker.setLatLng(event.latlng);
      await updateLocationAndAddress(event.latlng);
    });
  };

  useEffect(() => {
    if (showMap && leafletLoaded) {
      initializeLeafletMap();
    }

    return () => {
      if (leafletMapInstance.current) {
        leafletMapInstance.current.remove();
        leafletMapInstance.current = null;
      }
    };
  }, [showMap, leafletLoaded]);

  // Get current location
  const getCurrentLocation = () => {
    setLocationLoading(true);
    if (!navigator.geolocation) {
      showToast("Geolocation is not supported by this browser.", "error");
      setLocationLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          const address = await reverseGeocodeNominatim(latitude, longitude);

          setFormData(prev => ({
            ...prev,
            latitude: latitude.toString(),
            longitude: longitude.toString(),
            address: address
          }));
          showToast("Current location detected successfully!", "success");
          setLocationLoading(false);
        },
        (error) => {
          console.error("Geolocation error:", error);
          let errorMessage = "Unable to retrieve your location. Please enter manually or try map selection.";
          if (error.code === error.PERMISSION_DENIED) {
            errorMessage = "Location access denied. Please allow location permissions in your browser settings.";
          } else if (error.code === error.POSITION_UNAVAILABLE) {
            errorMessage = "Location information is unavailable. Check your device's GPS or network.";
          } else if (error.code === error.TIMEOUT) {
            errorMessage = "Location request timed out. Please try again or enter manually.";
          }
          showToast(errorMessage, "error");
          setLocationLoading(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  // Fixed API Calls with proper error handling and URL construction
  const fetchCategories = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/products/categories');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      console.log('Categories response:', data); // Debug log

      if (data.success && data.data) {
        setCategories([{ id: null, name: 'All', icon: '🛒' }, ...data.data]);
      } else {
        showToast('Failed to load categories: ' + (data.message || 'Unknown error'), 'error');
        setCategories([{ id: null, name: 'All', icon: '🛒' }]); // Fallback
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
      showToast('Network error fetching categories. Check if backend is running.', 'error');
      setCategories([{ id: null, name: 'All', icon: '🛒' }]); // Fallback
    }
  };

  // Fixed fetchProducts with proper URL construction
  const fetchProducts = async (category_id = null, query = '') => {
    setLoadingProducts(true);

    try {
      let url = 'http://localhost:3000/api/products/search';
      const params = new URLSearchParams();

      // Always use search endpoint for consistency
      if (query && query.trim()) {
        params.append('q', query.trim());
      }

      if (category_id !== null && category_id !== undefined) {
        params.append('category', category_id.toString());
      }

      // Add pagination parameters
      params.append('page', '1');
      params.append('limit', '50');

      const fullUrl = `${url}?${params.toString()}`;
      console.log('Fetching products from:', fullUrl); // Debug log

      const response = await fetch(fullUrl);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Products response:', data); // Debug log

      if (data.success) {
        const productsArray = data.data?.products || [];
        setProducts(productsArray);

        // Initialize product quantities
        const initialQuantities = {};
        productsArray.forEach(product => {
          if (product.quantities && product.quantities.length > 0) {
            initialQuantities[product.id] = {
              quantityId: product.quantities[0].id,
              value: 1,
              unit: product.quantities[0].unit_type
            };
          }
        });
        setProductQuantities(initialQuantities);
      } else {
        showToast('Failed to load products: ' + (data.message || 'Unknown error'), 'error');
        setProducts([]);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      showToast('Network error fetching products. Check if backend is running.', 'error');
      setProducts([]);
    } finally {
      setLoadingProducts(false);
    }
  };

  const fetchCartItems = async () => {
    setLoadingCart(true);
    try {
      const token = getAuthToken();
      if (!token) {
        setCartItems([]);
        setLoadingCart(false);
        return;
      }

      const response = await fetch('http://localhost:3000/api/cart', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        setCartItems(data.data?.items || []);
      } else {
        showToast(data.message || 'Failed to load cart items', 'error');
        setCartItems([]);
      }
    } catch (error) {
      console.error('Error fetching cart items:', error);
      showToast('Network error fetching cart items.', 'error');
      setCartItems([]);
    } finally {
      setLoadingCart(false);
    }
  };

  const fetchUserAddresses = async () => {
    setLoadingAddresses(true);
    try {
      const token = getAuthToken();
      if (!token) {
        setAddresses([]);
        setLoadingAddresses(false);
        return;
      }

      const response = await fetch('http://localhost:3000/api/addresses/my-addresses', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        setAddresses(data.data || []);
        // Set default address for order if available and not already selected
        if (!selectedAddressForOrder && data.data && data.data.length > 0) {
          const defaultAddr = data.data.find(addr => addr.is_default) || data.data[0];
          setSelectedAddressForOrder(defaultAddr);
        }
      } else {
        showToast(data.message || 'Failed to load addresses', 'error');
        setAddresses([]);
      }
    } catch (error) {
      console.error('Error fetching addresses:', error);
      showToast('Network error fetching addresses.', 'error');
      setAddresses([]);
    } finally {
      setLoadingAddresses(false);
    }
  };

  const fetchUserOrders = async () => {
    setLoadingOrders(true);
    try {
      const token = getAuthToken();
      if (!token) {
        setOrders([]);
        setLoadingOrders(false);
        return;
      }

      const response = await fetch('http://localhost:3000/api/orders', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        setOrders(data.data?.orders || []);
      } else {
        showToast(data.message || 'Failed to load orders', 'error');
        setOrders([]);
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
      showToast('Network error fetching orders.', 'error');
      setOrders([]);
    } finally {
      setLoadingOrders(false);
    }
  };

  // Fixed cart operations
  const handleAddToCart = async (product) => {
    const selectedQuantity = productQuantities[product.id];

    if (!selectedQuantity || !selectedQuantity.quantityId || selectedQuantity.value <= 0) {
      showToast('Please select a valid quantity and amount.', 'error');
      return;
    }

    const token = getAuthToken();
    if (!token) {
      showToast('Please log in to add items to cart.', 'error');
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/cart/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          product_id: product.id,
          quantity_id: selectedQuantity.quantityId,
          requested_quantity: selectedQuantity.value,
          notes: ''
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showToast('Item added to cart!', 'success');
        fetchCartItems();
      } else {
        showToast(data.message || 'Failed to add item to cart', 'error');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      showToast('Network error adding to cart.', 'error');
    }
  };

  const handleUpdateCartItem = async (cartItemId, newQuantity) => {
    if (newQuantity < 1) {
      showToast('Quantity cannot be less than 1.', 'error');
      return;
    }

    const token = getAuthToken();
    if (!token) {
      showToast('Please log in to update your cart.', 'error');
      return;
    }

    try {
      const response = await fetch(`http://localhost:3000/api/cart/update/${cartItemId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ requested_quantity: newQuantity })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showToast('Cart updated!', 'success');
        fetchCartItems();
      } else {
        showToast(data.message || 'Failed to update cart', 'error');
      }
    } catch (error) {
      console.error('Error updating cart:', error);
      showToast('Network error updating cart.', 'error');
    }
  };

  const handleRemoveFromCart = async (cartItemId) => {
    const token = getAuthToken();
    if (!token) {
      showToast('Please log in to modify your cart.', 'error');
      return;
    }

    // Using a custom modal/dialog instead of window.confirm
    const confirmed = await new Promise(resolve => {
      // For simplicity, using a quick modal implementation or a placeholder.
      // In a real app, this would be a custom UI modal.
      const userConfirm = window.confirm('Are you sure you want to remove this item from your cart?');
      resolve(userConfirm);
    });

    if (!confirmed) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:3000/api/cart/remove/${cartItemId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showToast('Item removed from cart!', 'success');
        fetchCartItems();
      } else {
        showToast(data.message || 'Failed to remove item', 'error');
      }
    } catch (error) {
      console.error('Error removing from cart:', error);
      showToast('Network error removing from cart.', 'error');
    }
  };

  const handleClearCart = async () => {
    const token = getAuthToken();
    if (!token) {
      showToast('Please log in to clear your cart.', 'error');
      return;
    }

    // Using a custom modal/dialog instead of window.confirm
    const confirmed = await new Promise(resolve => {
      const userConfirm = window.confirm('Are you sure you want to clear your entire cart?');
      resolve(userConfirm);
    });

    if (!confirmed) {
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/api/cart/clear', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showToast('Cart cleared!', 'success');
        setCartItems([]);
        setCurrentOrderStep('cart'); // Reset step if cart is cleared
      } else {
        showToast(data.message || 'Failed to clear cart', 'error');
      }
    } catch (error) {
      console.error('Error clearing cart:', error);
      showToast('Network error clearing cart.', 'error');
    }
  };

  const handleProceedToOrderInitial = () => {
    if (cartItems.length === 0) {
      showToast('Your cart is empty. Add items before ordering.', 'error');
      return;
    }
    // Automatically select default address if available, otherwise prompt user to select
    if (addresses.length === 0) {
      showToast('Please add a delivery address before ordering.', 'error');
      setCurrentView('address'); // Switch to address view to add one
      setShowCartModal(false); // Close cart modal
      return;
    }
    setCurrentOrderStep('address-selection');
  };

  const handlePlaceOrder = async () => {
    const token = getAuthToken();
    const user = getBuyerUser();

    if (!token || !user) {
      showToast('Please log in to proceed to order.', 'error');
      return;
    }

    if (cartItems.length === 0) {
      showToast('Your cart is empty. Add items before ordering.', 'error');
      return;
    }

    if (!selectedAddressForOrder) {
      showToast('Please select a delivery address.', 'error');
      return;
    }

    const order_name = `Order by ${user.name || user.email} - ${new Date().toLocaleDateString()}`;

    try {
      const response = await fetch('http://localhost:3000/api/orders/create-from-cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          order_name: order_name,
          delivery_address: selectedAddressForOrder.address_line || selectedAddressForOrder.address,
          delivery_latitude: parseFloat(selectedAddressForOrder.latitude || selectedAddressForOrder.lat),
          delivery_longitude: parseFloat(selectedAddressForOrder.longitude || selectedAddressForOrder.lng),
          cart_item_ids: cartItems.map(item => item.cart_item_id)
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showToast('Order placed successfully!', 'success');
        setCartItems([]);
        fetchUserOrders();
        setShowCartModal(false); // Close modal
        setCurrentOrderStep('cart'); // Reset order step
        setCurrentView('myOrders'); // Navigate to orders
      } else {
        showToast(data.message || 'Failed to place order.', 'error');
      }
    } catch (error) {
      console.error('Error creating order:', error);
      showToast('Network error placing order.', 'error');
    }
  };

  // Enhanced search handler
  const handleSearch = () => {
    console.log('Search triggered:', { searchQuery, activeCategory }); // Debug log
    fetchProducts(activeCategory, searchQuery);
  };

  // Enhanced category change handler
  const handleCategoryChange = (categoryId) => {
    console.log('Category changed:', categoryId); // Debug log
    setActiveCategory(categoryId);
    setSearchQuery(''); // Clear search when changing category
    fetchProducts(categoryId, ''); // Fetch products for new category
  };

  // Handle Edit Address
  const handleEditAddress = (address) => {
    setEditingAddressId(address.id);
    setFormData({
      name: address.name || '',
      address: address.address_line || address.address,
      latitude: address.latitude ? String(address.latitude) : '',
      longitude: address.longitude ? String(address.longitude) : ''
    });
    setIsDefault(address.is_default || false);
    setCurrentView('address'); // Switch to address view to edit
    setShowCartModal(false); // Close cart modal
    setShowMap(false); // Hide map initially when editing
    window.scrollTo({ top: 0, behavior: 'smooth' }); // Scroll to the form
  };

  // Handle Add/Update Address Submission
  const handleAddressSubmit = async () => {
    if (!formData.name.trim() || !formData.address.trim()) {
      showToast('Please fill in address name and address fields.', 'error');
      return;
    }

    const token = getAuthToken();
    if (!token) {
      showToast('Please log in to manage addresses.', 'error');
      return;
    }

    const addressData = {
      name: formData.name.trim(),
      address_line: formData.address.trim(),
      latitude: formData.latitude ? parseFloat(formData.latitude) : null,
      longitude: formData.longitude ? parseFloat(formData.longitude) : null,
      is_default: isDefault
    };

    try {
      let response;
      if (editingAddressId) {
        // Update existing address
        response = await fetch(`http://localhost:3000/api/addresses/${editingAddressId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(addressData)
        });
      } else {
        // Add new address
        response = await fetch('http://localhost:3000/api/addresses/add', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            ...addressData,
            is_default: addresses.length === 0 || isDefault // Make first address default if no others, or if explicitly set
          })
        });
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        showToast(`Address ${editingAddressId ? 'updated' : 'added'} successfully!`, 'success');
        setFormData({ name: '', address: '', latitude: '', longitude: '' });
        setIsDefault(false);
        setEditingAddressId(null); // Clear editing state
        setShowMap(false); // Hide map after submission
        fetchUserAddresses(); // Refresh addresses
      } else {
        showToast(data.message || `Failed to ${editingAddressId ? 'update' : 'add'} address`, 'error');
      }
    } catch (error) {
      console.error(`Error ${editingAddressId ? 'updating' : 'adding'} address:`, error);
      showToast(`Network error ${editingAddressId ? 'updating' : 'adding'} address.`, 'error');
    }
  };

  const handleCancelEdit = () => {
    setEditingAddressId(null);
    setFormData({ name: '', address: '', latitude: '', longitude: '' });
    setIsDefault(false);
    setShowMap(false); // Hide map when canceling edit
  };


  // Initial data loading
  useEffect(() => {
    const user = getBuyerUser();
    if (!user) {
      setRequiresLogin(true);
      showToast('Please log in to access the dashboard.', 'error');
    } else {
      setRequiresLogin(false);
      setUserProfile(user);
      fetchCategories();
      fetchProducts(null, ''); // Load all products initially
      fetchCartItems();
      fetchUserAddresses();
      fetchUserOrders();
    }
  }, []);

  const renderContent = () => {
    if (requiresLogin) {
      return (
          <div className="text-center py-20 bg-white dark:bg-zinc-800 rounded-2xl shadow-sm border border-gray-100 dark:border-zinc-700">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 dark:text-zinc-100 mb-4">Login Required</h2>
            <p className="text-gray-600 dark:text-zinc-300 mb-6">Please log in to view the buyer dashboard content.</p>
            <Link to="/buyer/login" className="px-6 py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors duration-200">
              Go to Login
            </Link>
          </div>
      );
    }

    switch (currentView) {
      case 'products':
        return (
            <>
              {/* Enhanced Search Bar */}
              <div className="bg-white dark:bg-zinc-800 p-6 rounded-2xl shadow-sm mb-6 border border-gray-100 dark:border-zinc-700">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-zinc-400" />
                  <input
                      type="text"
                      placeholder="Search for food items, vendors, categories..."
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 dark:border-zinc-600 focus:border-green-500 transition-all duration-300 outline-none bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleSearch();
                        }
                      }}
                  />
                  <button
                      onClick={handleSearch}
                      className="absolute right-2 top-1/2 -translate-y-1/2 bg-green-500 text-white px-5 py-2 rounded-lg hover:bg-green-600 transition-colors duration-200"
                  >
                    Search
                  </button>
                </div>
              </div>

              {/* Enhanced Categories */}
              <div className="bg-white dark:bg-zinc-800 p-6 rounded-2xl shadow-sm mb-6 border border-gray-100 dark:border-zinc-700">
                <h2 className="text-xl font-semibold text-gray-800 dark:text-zinc-100 mb-4">Shop by Categories</h2>
                {categories.length > 0 ? (
                    <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-4">
                      {categories.map(category => (
                          <button
                              key={category.id || 'all'}
                              onClick={() => handleCategoryChange(category.id)}
                              className={`flex flex-col items-center p-3 rounded-xl transition-colors duration-200 ${
                                  activeCategory === category.id
                                      ? 'bg-green-100 text-green-700 border-2 border-green-500 dark:bg-green-700 dark:text-white dark:border-green-400'
                                      : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border border-gray-200 dark:bg-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-600 dark:border-zinc-600'
                              }`}
                          >
                            {category.icon ? (
                                <span className="text-2xl mb-1">{category.icon}</span>
                            ) : (
                                category.id === null ? <Home className="w-6 h-6 mb-1" /> : <Package className="w-6 h-6 mb-1" />
                            )}
                            <span className="text-xs font-medium text-center">{category.name}</span>
                          </button>
                      ))}
                    </div>
                ) : (
                    <div className="text-center py-5 text-gray-500 dark:text-zinc-400">Loading categories...</div>
                )}
              </div>

              {/* Product Listing */}
              <h2 className="text-xl font-semibold text-gray-800 dark:text-zinc-100 mb-4">
                {searchQuery ? `Search results for "${searchQuery}"` :
                    activeCategory ? `Products in ${categories.find(c => c.id === activeCategory)?.name || 'Category'}` :
                        'Fresh Products Near You'}
              </h2>

              {loadingProducts ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                    {[...Array(6)].map((_, i) => (
                        <div key={i} className="bg-white dark:bg-zinc-800 rounded-2xl shadow-sm p-4 h-64">
                          <div className="h-32 bg-gray-200 dark:bg-zinc-700 rounded-lg mb-3"></div>
                          <div className="h-4 bg-gray-200 dark:bg-zinc-700 rounded mb-2 w-3/4"></div>
                          <div className="h-4 bg-gray-200 dark:bg-zinc-700 rounded w-1/2"></div>
                        </div>
                    ))}
                  </div>
              ) : products.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map(product => (
                        <div key={product.id} className="bg-white dark:bg-zinc-800 rounded-2xl shadow-md overflow-hidden border border-gray-100 dark:border-zinc-700 flex flex-col">
                          <div className="w-full h-40 bg-gray-100 dark:bg-zinc-700 flex items-center justify-center text-gray-400">
                            <Package className="w-16 h-16" />
                          </div>
                          <div className="p-4 flex flex-col flex-grow">
                            <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100 mb-1">{product.name}</h3>
                            <p className="text-sm text-gray-600 dark:text-zinc-300 mb-2">{product.description}</p>
                            {product.distance && (
                                <div className="flex items-center text-gray-500 dark:text-zinc-400 text-sm mb-3">
                                  <MapPin className="w-4 h-4 mr-1 text-green-500" />
                                  <span>{product.distance} km</span>
                                </div>
                            )}

                            {product.quantities && product.quantities.length > 0 ? (
                                <div className="mt-auto space-y-3">
                                  <select
                                      className="w-full p-2 border border-gray-300 dark:border-zinc-600 rounded-lg text-sm bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                                      value={productQuantities[product.id]?.quantityId || product.quantities[0].id}
                                      onChange={(e) => {
                                        const newQuantityId = parseInt(e.target.value);
                                        const selectedUnit = product.quantities.find(q => q.id === newQuantityId)?.unit_type || '';
                                        setProductQuantities(prev => ({
                                          ...prev,
                                          [product.id]: {
                                            ...prev[product.id],
                                            quantityId: newQuantityId,
                                            unit: selectedUnit
                                          }
                                        }));
                                      }}
                                  >
                                    {product.quantities.map(q => (
                                        <option key={q.id} value={q.id}>
                                          {q.quantity} {q.unit_type}
                                        </option>
                                    ))}
                                  </select>

                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center border border-gray-300 dark:border-zinc-600 rounded-lg">
                                      <button
                                          onClick={() => setProductQuantities(prev => ({
                                            ...prev,
                                            [product.id]: {
                                              ...prev[product.id],
                                              value: Math.max(1, (prev[product.id]?.value || 1) - 1)
                                            }
                                          }))}
                                          className="p-2 text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-600 rounded-l-lg"
                                      >
                                        <Minus className="w-4 h-4" />
                                      </button>
                                      <input
                                          type="number"
                                          value={productQuantities[product.id]?.value || 1}
                                          onChange={(e) => setProductQuantities(prev => ({
                                            ...prev,
                                            [product.id]: {
                                              ...prev[product.id],
                                              value: parseInt(e.target.value) || 1
                                            }
                                          }))}
                                          className="w-16 text-center border-l border-r border-gray-300 dark:border-zinc-600 outline-none text-sm bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                                          min="1"
                                      />
                                      <button
                                          onClick={() => setProductQuantities(prev => ({
                                            ...prev,
                                            [product.id]: {
                                              ...prev[product.id],
                                              value: (prev[product.id]?.value || 1) + 1
                                            }
                                          }))}
                                          className="p-2 text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-600 rounded-r-lg"
                                      >
                                        <Plus className="w-4 h-4" />
                                      </button>
                                    </div>
                                    <button
                                        onClick={() => handleAddToCart(product)}
                                        className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors duration-200 text-sm"
                                    >
                                      Add to Cart
                                    </button>
                                  </div>
                                </div>
                            ) : (
                                <div className="mt-auto text-center text-red-500 font-semibold py-2">
                                  Out of Stock
                                </div>
                            )}
                          </div>
                        </div>
                    ))}
                  </div>
              ) : (
                  <div className="text-center py-10 text-gray-500 dark:text-zinc-400">
                    {searchQuery || activeCategory ? 'No products found matching your criteria.' : 'No products available.'}
                  </div>
              )}
            </>
        );

      case 'myOrders':
        return (
            <div className="bg-white dark:bg-zinc-800 p-6 rounded-2xl shadow-sm mb-6 border border-gray-100 dark:border-zinc-700 w-full"> {/* Added w-full for centering effect */}
              <h2 className="text-2xl font-bold text-gray-800 dark:text-zinc-100 mb-6">My Orders</h2>
              {loadingOrders ? (
                  <div className="flex items-center justify-center py-10 text-gray-500 dark:text-zinc-400">
                    <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading Orders...
                  </div>
              ) : orders.length > 0 ? (
                  <div className="space-y-6">
                    {orders.map(order => (
                        <div key={order.id} className="border border-gray-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm">
                          <div className="flex justify-between items-center mb-3">
                            <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100">Order #{order.id}</h3>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                order.status === 'Delivered' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-white' :
                                    order.status === 'Pending' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-700 dark:text-white' :
                                        'bg-gray-100 text-gray-700 dark:bg-zinc-700 dark:text-zinc-200'
                            }`}>
                        {order.status}
                      </span>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-zinc-300 mb-2">
                            Date: {new Date(order.created_at || order.date).toLocaleDateString()}
                          </p>
                          {order.items && order.items.length > 0 ? (
                              <ul className="list-disc list-inside text-sm text-gray-700 dark:text-zinc-300 space-y-1">
                                {order.items.map((item, idx) => (
                                    <li key={idx}>
                                      {item.product_name} ({item.requested_quantity} {item.quantity_unit})
                                      {item.price_at_order && ` - ₹${item.price_at_order}`}
                                    </li>
                                ))}
                              </ul>
                          ) : (
                              <p className="text-sm text-gray-500 dark:text-zinc-400">No item details available.</p>
                          )}
                          {order.total && (
                              <div className="text-right font-bold text-md mt-3 text-gray-900 dark:text-zinc-100">
                                Total: ₹{order.total}
                              </div>
                          )}
                        </div>
                    ))}
                  </div>
              ) : (
                  <div className="text-center py-10 text-gray-500 dark:text-zinc-400">You have no past orders.</div>
              )}
            </div>
        );

      case 'address':
        return (
            <>
              {/* Floating Rectangle for Add/Edit Address with Map and Form */}
              <div className="bg-white dark:bg-zinc-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-zinc-700 mb-6 lg:grid lg:grid-cols-2 lg:gap-6 w-full"> {/* Added w-full for centering effect */}
                {/* Left Half: Map Container and Controls */}
                <div className="flex flex-col h-full min-h-[400px] mb-6 lg:mb-0">
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-zinc-100 mb-4">
                    Select Location on Map
                  </h3>
                  {!showMap ? (
                      <div className="flex-grow flex items-center justify-center border border-gray-200 dark:border-zinc-700 rounded-lg bg-gray-50 dark:bg-zinc-700 text-center text-gray-500 dark:text-zinc-400 p-4">
                        <p className="mr-2">Click to open map:</p>
                        <button
                            onClick={() => setShowMap(true)}
                            className="p-3 bg-green-500 text-white rounded-full shadow hover:bg-green-600 transition-colors duration-200"
                            title="Open Map"
                        >
                          <MapPin className="w-6 h-6" />
                        </button>
                      </div>
                  ) : (
                      <>
                        <div ref={mapRef} className="flex-grow w-full rounded-lg border border-gray-300 dark:border-zinc-600 mb-4"></div>
                        <button
                            onClick={() => setShowMap(false)}
                            className="w-full py-2 bg-gray-500 text-white rounded-full hover:bg-gray-600 transition-colors duration-200"
                        >
                          Close Map
                        </button>
                      </>
                  )}
                </div>

                {/* Right Half: Add/Edit Address Form */}
                <div className="flex flex-col h-full">
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-zinc-100 mb-4">
                    {editingAddressId ? 'Edit Address Details' : 'Add New Address Details'}
                  </h3>
                  <div className="space-y-4 flex-grow">
                    <input
                        type="text"
                        placeholder="Address Name (e.g., Home, Office)"
                        className="w-full p-3 border border-gray-300 dark:border-zinc-600 rounded-lg bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    />
                    <textarea
                        placeholder="Full Address"
                        className="w-full p-3 border border-gray-300 dark:border-zinc-600 rounded-lg h-24 bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                        value={formData.address}
                        onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <input
                          type="number"
                          placeholder="Latitude"
                          className="w-full p-3 border border-gray-300 dark:border-zinc-600 rounded-lg bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                          value={formData.latitude}
                          onChange={(e) => setFormData(prev => ({ ...prev, latitude: e.target.value }))}
                          step="any"
                      />
                      <input
                          type="number"
                          placeholder="Longitude"
                          className="w-full p-3 border border-gray-300 dark:border-zinc-600 rounded-lg bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100"
                          value={formData.longitude}
                          onChange={(e) => setFormData(prev => ({ ...prev, longitude: e.target.value }))}
                          step="any"
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                          type="checkbox"
                          id="isDefault"
                          checked={isDefault}
                          onChange={(e) => setIsDefault(e.target.checked)}
                          className="h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500 dark:bg-zinc-700 dark:border-zinc-600"
                      />
                      <label htmlFor="isDefault" className="text-sm font-medium text-gray-700 dark:text-zinc-300">Set as default address</label>
                    </div>

                    <button
                        onClick={getCurrentLocation}
                        disabled={locationLoading}
                        className="w-full py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200 flex items-center justify-center"
                    >
                      {locationLoading ? (
                          <Loader2 className="w-5 h-5 animate-spin mr-2" />
                      ) : (
                          <MapPin className="w-5 h-5 mr-2" />
                      )}
                      Get Current Location
                    </button>
                  </div>

                  <div className="flex gap-3 mt-auto pt-4">
                    <button
                        onClick={handleAddressSubmit}
                        className="flex-1 py-3 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600 transition-colors duration-200"
                    >
                      {editingAddressId ? 'Save Changes' : 'Add Address'}
                    </button>
                    {editingAddressId && (
                        <button
                            onClick={handleCancelEdit}
                            className="flex-1 py-3 bg-gray-300 text-gray-800 dark:bg-zinc-700 dark:text-zinc-200 rounded-lg hover:bg-gray-400 dark:hover:bg-zinc-600 transition-colors duration-200"
                        >
                          Cancel Edit
                        </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Existing Addresses Display */}
              <div className="bg-white dark:bg-zinc-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-zinc-700 w-full"> {/* Added w-full for centering effect */}
                <h2 className="text-2xl font-bold text-gray-800 dark:text-zinc-100 mb-6">Existing Addresses</h2>
                {loadingAddresses ? (
                    <div className="flex items-center justify-center py-10 text-gray-500 dark:text-zinc-400">
                      <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading Addresses...
                    </div>
                ) : addresses.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {addresses.map(address => (
                          <div key={address.id} className="border border-gray-200 dark:border-zinc-700 rounded-xl p-4 shadow-sm flex items-start space-x-3">
                            <MapPin className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                            <div className="flex-grow">
                              <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100 mb-1">
                                {address.name || 'Unnamed Address'}
                                {address.is_default && (
                                    <span className="ml-2 px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full dark:bg-green-700 dark:text-white">
                            Default
                          </span>
                                )}
                              </h3>
                              <p className="text-gray-700 dark:text-zinc-300">{address.address_line}</p>
                              {address.latitude && address.longitude && (
                                  <p className="text-sm text-gray-500 dark:text-zinc-400">
                                    Lat: {parseFloat(address.latitude).toFixed(6)},
                                    Lng: {parseFloat(address.longitude).toFixed(6)}
                                  </p>
                              )}
                            </div>
                            <div className="flex space-x-2">
                              <button
                                  onClick={() => handleEditAddress(address)}
                                  className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors duration-200 text-sm flex items-center justify-center dark:bg-blue-700 dark:text-white dark:hover:bg-blue-600"
                                  title="Edit Address"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                  onClick={async () => {
                                    // Using a custom modal/dialog instead of window.confirm
                                    const confirmed = await new Promise(resolve => {
                                      const userConfirm = window.confirm('Are you sure you want to delete this address?');
                                      resolve(userConfirm);
                                    });

                                    if (!confirmed) {
                                      return;
                                    }

                                    const token = getAuthToken();
                                    if (!token) {
                                      showToast('Please log in to delete an address.', 'error');
                                      return;
                                    }

                                    try {
                                      const response = await fetch(`http://localhost:3000/api/addresses/${address.id}`, {
                                        method: 'DELETE',
                                        headers: {
                                          'Authorization': `Bearer ${token}`
                                        }
                                      });

                                      if (!response.ok) {
                                        throw new Error(`HTTP error! status: ${response.status}`);
                                      }

                                      const data = await response.json();
                                      if (data.success) {
                                        showToast('Address deleted successfully!', 'success');
                                        fetchUserAddresses();
                                      } else {
                                        showToast(data.message || 'Failed to delete address', 'error');
                                      }
                                    } catch (error) {
                                      console.error('Error deleting address:', error);
                                      showToast('Network error deleting address.', 'error');
                                    }
                                  }}
                                  className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors duration-200 text-sm flex items-center justify-center dark:bg-red-700 dark:text-white dark:hover:bg-red-600"
                                  title="Delete Address"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                      ))}
                    </div>
                ) : (
                    <div className="text-center py-10 text-gray-500 dark:text-zinc-400">
                      No addresses found. Add your first address above.
                    </div>
                )}
              </div>
            </>
        );

      default:
        return null;
    }
  };

  return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-zinc-900 text-zinc-100' : 'bg-gray-50 text-gray-800'} font-inter`}>
        {/* Toast Notification */}
        {toast.show && (
            <div
                className={`fixed top-5 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3 transition-all duration-300 ease-out ${
                    toast.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"
                }`}
            >
              {toast.type === "success" ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              <span className="font-semibold">{toast.message}</span>
            </div>
        )}

        {/* Header */}
        <header className="bg-white dark:bg-zinc-800 shadow-sm py-4 px-6 flex items-center justify-between border-b border-gray-100 dark:border-zinc-700">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-green-600 text-2xl font-bold">FreshMart</Link>
            <nav className="hidden md:flex space-x-6 ml-8">
              <button
                  onClick={() => {
                    setCurrentView('products');
                    setShowMap(false); // Ensure map is hidden when switching views
                  }}
                  className={`font-medium ${currentView === 'products' ? 'text-green-600' : 'text-gray-600 dark:text-zinc-300 hover:text-green-600'}`}
              >
                Products
              </button>
              <button
                  onClick={() => {
                    setCurrentView('myOrders');
                    setShowMap(false); // Ensure map is hidden when switching views
                  }}
                  className={`font-medium ${currentView === 'myOrders' ? 'text-green-600' : 'text-gray-600 dark:text-zinc-300 hover:text-green-600'}`}
              >
                My Orders
              </button>
              <button
                  onClick={() => {
                    setCurrentView('address');
                    // showMap will be controlled by a button in the address section itself
                  }}
                  className={`font-medium ${currentView === 'address' ? 'text-green-600' : 'text-gray-600 dark:text-zinc-300 hover:text-green-600'}`}
              >
                Address
              </button>
            </nav>
          </div>

          <div className="flex items-center space-x-6">
            <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-2 rounded-full text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-700">
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            {userProfile && (
                <div className="flex items-center space-x-2">
                  <User className="w-5 h-5 text-gray-600 dark:text-zinc-300" />
                  <span className="text-gray-700 dark:text-zinc-200 font-medium">{userProfile.name || userProfile.email}</span>
                </div>
            )}
            <div className="relative cursor-pointer" onClick={() => setShowCartModal(true)}>
              <ShoppingCart className="w-6 h-6 text-gray-600 dark:text-zinc-300 hover:text-green-600" />
              {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {cartItems.length}
              </span>
              )}
            </div>
            <div className="relative group">
              <button className="flex items-center text-gray-600 dark:text-zinc-300 hover:text-green-600 font-medium">
                Profile <ChevronDown className="w-4 h-4 ml-1" />
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-zinc-700 rounded-md shadow-lg py-1 hidden group-hover:block z-20 border border-gray-100 dark:border-zinc-600">
                <Link to="/buyer/profile" className="block px-4 py-2 text-sm text-gray-700 dark:text-zinc-200 hover:bg-gray-100 dark:hover:bg-zinc-600">
                  My Profile
                </Link>
                <button
                    onClick={() => {
                      localStorage.removeItem('buyer_token');
                      localStorage.removeItem('buyer_user');
                      navigate('/buyer/login');
                    }}
                    className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 dark:hover:bg-zinc-600"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        {/* Added px-4 for smaller screens, and lg:px-24 (approx 10% padding) for larger screens */}
        <main className="container mx-auto px-4 py-6 lg:px-24 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column (Main Content) */}
          <div className={`${
              (currentView === 'myOrders' || currentView === 'address')
                  ? 'lg:col-span-3 flex flex-col items-center' // Changed to lg:col-span-3 and flex items-center to truly center the content for orders and address views
                  : 'lg:col-span-2' // Default span for products view
          }`}>
            {renderContent()}
          </div>

          {/* Right Column (Dynamic: Cart Sidebar - only for products view) */}
          {currentView === 'products' && (
              <div className="lg:col-span-1 hidden lg:block"> {/* Only show for products view on large screens */}
                <div className="bg-white dark:bg-zinc-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-zinc-700 sticky top-6">
                  <h2 className="text-xl font-bold text-gray-800 dark:text-zinc-100 mb-4 flex items-center">
                    <ShoppingCart className="w-6 h-6 mr-2 text-green-600" /> Shopping Cart
                  </h2>

                  {loadingCart ? (
                      <div className="flex items-center justify-center py-10 text-gray-500 dark:text-zinc-400">
                        <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading Cart...
                      </div>
                  ) : cartItems.length > 0 ? (
                      <>
                        <div className="space-y-4 mb-6 max-h-80 overflow-y-auto pr-2">
                          {cartItems.map(item => (
                              <div key={item.cart_item_id} className="flex items-center justify-between border-b border-gray-100 dark:border-zinc-700 pb-3">
                                <div>
                                  <p className="font-medium text-gray-900 dark:text-zinc-100">{item.product_name}</p>
                                  <p className="text-sm text-gray-500 dark:text-zinc-400">{item.quantity_value} {item.quantity_unit}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <button
                                      onClick={() => handleUpdateCartItem(item.cart_item_id, Math.max(1, item.requested_quantity - 1))}
                                      className="p-1.5 border border-gray-300 dark:border-zinc-600 rounded-md text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-700"
                                  >
                                    <Minus className="w-4 h-4" />
                                  </button>
                                  <span className="font-semibold text-gray-800 dark:text-zinc-100">{item.requested_quantity}</span>
                                  <button
                                      onClick={() => handleUpdateCartItem(item.cart_item_id, item.requested_quantity + 1)}
                                      className="p-1.5 border border-gray-300 dark:border-zinc-600 rounded-md text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-700"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </button>
                                  <button
                                      onClick={() => handleRemoveFromCart(item.cart_item_id)}
                                      className="p-1.5 text-red-500 hover:bg-red-100 dark:hover:bg-red-700 dark:text-red-300 rounded-md"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                          ))}
                        </div>

                        <div className="mt-6 space-y-3">
                          <button
                              onClick={handleClearCart}
                              className="w-full py-3 bg-red-100 text-red-600 rounded-lg font-semibold hover:bg-red-200 transition-colors duration-200 dark:bg-red-700 dark:text-white dark:hover:bg-red-600"
                          >
                            Clear Cart
                          </button>
                          <button
                              onClick={handleProceedToOrderInitial}
                              className="w-full py-3 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600 transition-colors duration-200 flex items-center justify-center"
                          >
                            Proceed to Order <ChevronsRight className="w-5 h-5 ml-2" />
                          </button>
                          <div className="flex justify-center space-x-3 mt-4">
                            <CreditCard className="w-8 h-8 text-gray-400 dark:text-zinc-400" />
                          </div>
                        </div>
                      </>
                  ) : (
                      <div className="text-center py-10 text-gray-500 dark:text-zinc-400">Your cart is empty. Start shopping!</div>
                  )}
                </div>
              </div>
          )}
        </main>

        {/* Cart Modal */}
        {showCartModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 px-4"> {/* Changed pt-20 to items-center for vertical centering, added px-4 */}
              <div className="bg-white dark:bg-zinc-800 rounded-2xl shadow-xl w-full max-w-lg p-6 relative"> {/* Removed mx-4 here as it's handled by parent px-4 */}
                <button
                    onClick={() => {
                      setShowCartModal(false);
                      setCurrentOrderStep('cart'); // Reset order step when closing modal
                    }}
                    className="absolute top-4 right-4 p-2 rounded-full text-gray-500 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-700"
                >
                  <X className="w-6 h-6" />
                </button>

                {currentOrderStep === 'cart' && (
                    <>
                      <h2 className="text-2xl font-bold text-gray-800 dark:text-zinc-100 mb-6 flex items-center">
                        <ShoppingCart className="w-7 h-7 mr-3 text-green-600" /> Your Cart
                      </h2>

                      {loadingCart ? (
                          <div className="flex items-center justify-center py-10 text-gray-500 dark:text-zinc-400">
                            <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading Cart...
                          </div>
                      ) : cartItems.length > 0 ? (
                          <>
                            <div className="space-y-4 mb-6 max-h-96 overflow-y-auto pr-2">
                              {cartItems.map(item => (
                                  <div key={item.cart_item_id} className="flex items-center justify-between border-b border-gray-100 dark:border-zinc-700 pb-3">
                                    <div>
                                      <p className="font-medium text-gray-900 dark:text-zinc-100">{item.product_name}</p>
                                      <p className="text-sm text-gray-500 dark:text-zinc-400">{item.quantity_value} {item.quantity_unit}</p>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <button
                                          onClick={() => handleUpdateCartItem(item.cart_item_id, Math.max(1, item.requested_quantity - 1))}
                                          className="p-1.5 border border-gray-300 dark:border-zinc-600 rounded-md text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-700"
                                      >
                                        <Minus className="w-4 h-4" />
                                      </button>
                                      <span className="font-semibold text-gray-800 dark:text-zinc-100">{item.requested_quantity}</span>
                                      <button
                                          onClick={() => handleUpdateCartItem(item.cart_item_id, item.requested_quantity + 1)}
                                          className="p-1.5 border border-gray-300 dark:border-zinc-600 rounded-md text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-700"
                                      >
                                        <Plus className="w-4 h-4" />
                                      </button>
                                      <button
                                          onClick={() => handleRemoveFromCart(item.cart_item_id)}
                                          className="p-1.5 text-red-500 hover:bg-red-100 dark:hover:bg-red-700 dark:text-red-300 rounded-md"
                                      >
                                        <X className="w-4 h-4" />
                                      </button>
                                    </div>
                                  </div>
                              ))}
                            </div>

                            <div className="mt-6 space-y-3">
                              <button
                                  onClick={handleClearCart}
                                  className="w-full py-3 bg-red-100 text-red-600 rounded-lg font-semibold hover:bg-red-200 transition-colors duration-200 dark:bg-red-700 dark:text-white dark:hover:bg-red-600"
                              >
                                Clear Cart
                              </button>
                              <button
                                  onClick={handleProceedToOrderInitial}
                                  className="w-full py-3 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600 transition-colors duration-200 flex items-center justify-center"
                              >
                                Proceed to Order <ChevronsRight className="w-5 h-5 ml-2" />
                              </button>
                              <div className="flex justify-center space-x-3 mt-4">
                                <CreditCard className="w-8 h-8 text-gray-400 dark:text-zinc-400" />
                              </div>
                            </div>
                          </>
                      ) : (
                          <div className="text-center py-10 text-gray-500 dark:text-zinc-400">Your cart is empty. Start shopping!</div>
                      )}
                    </>
                )}

                {currentOrderStep === 'address-selection' && (
                    <>
                      <h2 className="text-2xl font-bold text-gray-800 dark:text-zinc-100 mb-6 flex items-center">
                        <MapPin className="w-7 h-7 mr-3 text-blue-600" /> Select Delivery Address
                      </h2>
                      {loadingAddresses ? (
                          <div className="flex items-center justify-center py-10 text-gray-500 dark:text-zinc-400">
                            <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading Addresses...
                          </div>
                      ) : addresses.length > 0 ? (
                          <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                            {addresses.map(address => (
                                <div
                                    key={address.id}
                                    className={`p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
                                        selectedAddressForOrder?.id === address.id
                                            ? 'border-green-500 ring-2 ring-green-200 bg-green-50 dark:bg-green-900 dark:ring-green-700'
                                            : 'border-gray-200 dark:border-zinc-700 bg-white dark:bg-zinc-700 hover:border-gray-400 dark:hover:border-zinc-500'
                                    }`}
                                    onClick={() => setSelectedAddressForOrder(address)}
                                >
                                  <div className="flex items-center justify-between">
                                    <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100">
                                      {address.name || 'Unnamed Address'}
                                      {address.is_default && (
                                          <span className="ml-2 px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full dark:bg-green-700 dark:text-white">
                                            Default
                                          </span>
                                      )}
                                    </h3>
                                    {selectedAddressForOrder?.id === address.id && (
                                        <CheckSquare className="w-6 h-6 text-green-600" />
                                    )}
                                  </div>
                                  <p className="text-gray-700 dark:text-zinc-300 text-sm">{address.address_line}</p>
                                  {address.latitude && address.longitude && (
                                      <p className="text-xs text-gray-500 dark:text-zinc-400">
                                        Lat: {parseFloat(address.latitude).toFixed(6)},
                                        Lng: {parseFloat(address.longitude).toFixed(6)}
                                      </p>
                                  )}
                                  <button
                                      onClick={(e) => { e.stopPropagation(); handleEditAddress(address); }}
                                      className="mt-2 text-blue-500 hover:text-blue-700 text-sm flex items-center"
                                  >
                                    <Edit className="w-4 h-4 mr-1" /> Edit
                                  </button>
                                </div>
                            ))}
                            <button
                                onClick={() => {
                                  setCurrentView('address'); // Go to full address management view
                                  setShowCartModal(false); // Close cart modal
                                  setEditingAddressId(null); // Clear editing state for new address
                                  setFormData({ name: '', address: '', latitude: '', longitude: '' }); // Clear form
                                  setIsDefault(false);
                                  setShowMap(false); // Hide map when redirecting to address management
                                }}
                                className="w-full py-2 bg-blue-500 text-white rounded-lg font-semibold hover:bg-blue-600 transition-colors duration-200 mt-4"
                            >
                              Add New Address
                            </button>
                          </div>
                      ) : (
                          <div className="text-center py-10 text-gray-500 dark:text-zinc-400">
                            You have no addresses. Please add one to proceed.
                            <button
                                onClick={() => {
                                  setCurrentView('address');
                                  setShowCartModal(false);
                                }}
                                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200"
                            >
                              Go to Addresses
                            </button>
                          </div>
                      )}
                      <div className="flex justify-between mt-6">
                        <button
                            onClick={() => setCurrentOrderStep('cart')}
                            className="px-5 py-2 bg-gray-300 text-gray-800 dark:bg-zinc-700 dark:text-zinc-200 rounded-lg hover:bg-gray-400 dark:hover:bg-zinc-600 transition-colors duration-200"
                        >
                          Back to Cart
                        </button>
                        <button
                            onClick={handlePlaceOrder}
                            disabled={!selectedAddressForOrder}
                            className={`px-5 py-2 rounded-lg font-semibold transition-colors duration-200 ${
                                selectedAddressForOrder ? 'bg-green-500 text-white hover:bg-green-600' : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            }`}
                        >
                          Confirm Order
                        </button>
                      </div>
                    </>
                )}
              </div>
            </div>
        )}
      </div>
  );
};

export default BuyerDashboard;