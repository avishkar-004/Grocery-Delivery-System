import React, { useState, useEffect, useRef } from "react";
import { BrowserRouter as Router, useNavigate } from "react-router-dom"; // Import BrowserRouter and useNavigate
import {
  ArrowLeft,
  ShoppingCart, // Re-using ShoppingCart for the main SVG on the left
  MapPin,
  Loader2,
  CheckCircle,
  AlertCircle,
  Mail,
  Eye,
  EyeOff,
  Map,
  Navigation,
  User,
  KeyRound,
  Home,
  ArrowRight
} from "lucide-react";

// Internal component that contains the actual form logic and uses useNavigate
// This component is now the default export, to be used directly within your main App's Router.
const SellerRegister = () => {
  const navigate = useNavigate(); // Initialize useNavigate hook for redirection

  // State to hold all form data
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    gender: "",
    date_of_birth: "",
    address: "",
    latitude: "",
    longitude: ""
  });

  // State for loading indicators
  const [isLoading, setIsLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [isCheckingPassword, setIsCheckingPassword] = useState(false); // New state for password strength check loading

  // State for password visibility toggles
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // State to manage the current step of the multi-step form
  const [currentStep, setCurrentStep] = useState(1);

  // State for OTP input (used in step 4)
  const [otpCode, setOtpCode] = useState("");

  // State for form validation errors
  const [errors, setErrors] = useState({});

  // State for toast notifications
  const [toast, setToast] = useState({ show: false, message: "", type: "" });

  // New state for LLM-powered password strength feedback
  const [passwordStrength, setPasswordStrength] = useState({ rating: '', tip: '' });

  // Refs for Leaflet map integration
  const mapRef = useRef(null); // Reference to the DOM element where the map will be rendered
  const leafletMapInstance = useRef(null); // Reference to the Leaflet map object
  const leafletMarkerInstance = useRef(null); // Reference to the Leaflet marker object
  const [leafletLoaded, setLeafletLoaded] = useState(false); // State to track if Leaflet.js script is loaded
  const [showMap, setShowMap] = useState(false); // Controls the visibility of the map container

  // Helper function to display toast notifications
  const showToast = (message, type = "success") => {
    setToast({ show: true, message, type });
    // Hide toast after 4 seconds
    setTimeout(() => setToast({ show: false, message: "", type: "" }), 4000);
  };

  // Generic input change handler for form fields
  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error for the field if user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  // --- LLM Integration: Password Strength Check using Gemini API ---
  useEffect(() => {
    const checkPasswordStrength = async () => {
      const password = formData.password.trim();
      if (password.length === 0) {
        setPasswordStrength({ rating: '', tip: '' });
        return;
      }
      setIsCheckingPassword(true); // Indicate that strength check is in progress
      try {
        // Construct the prompt for the LLM
        const prompt = `Rate the strength of this password (weak, medium, strong) and give a very short, concise tip (max 10 words) to improve it if it's not strong. Do not include "Strength:" or "Tip:". Just the rating and the tip. Password: "${password}"`;
        let chatHistory = [];
        chatHistory.push({ role: "user", parts: [{ text: prompt }] });
        const payload = { contents: chatHistory };
        // API key will be provided by Canvas runtime if empty
        const apiKey = "";
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const result = await response.json();

        // Parse the LLM's response for strength rating and tip
        if (result.candidates && result.candidates.length > 0 && result.candidates[0].content && result.candidates[0].content.parts && result.candidates[0].content.parts.length > 0) {
          const text = result.candidates[0].content.parts[0].text;
          const lowerText = text.toLowerCase();
          let rating = '';
          let tip = text; // Default tip to full response if parsing fails

          // Simple keyword-based parsing for strength
          if (lowerText.includes('strong')) {
            rating = 'strong';
          } else if (lowerText.includes('medium')) {
            rating = 'medium';
          } else {
            rating = 'weak';
          }
          // Try to extract a more specific tip if the response contains one
          const tipMatch = text.match(/(strong|medium|weak)\s*[:.]?\s*(.*)/i);
          if (tipMatch && tipMatch[2]) {
            tip = tipMatch[2].trim();
          }

          setPasswordStrength({ rating, tip });
        } else {
          setPasswordStrength({ rating: '', tip: 'Could not check strength.' });
        }
      } catch (error) {
        console.error("LLM password strength check error:", error);
        setPasswordStrength({ rating: '', tip: 'Error checking strength.' });
      } finally {
        setIsCheckingPassword(false); // End loading for strength check
      }
    };

    // Debounce the LLM call to avoid excessive API requests
    const handler = setTimeout(() => {
      checkPasswordStrength();
    }, 500); // Wait 500ms after last keystroke

    return () => {
      clearTimeout(handler); // Cleanup: clear timeout if password changes again
    };
  }, [formData.password]); // Dependency array: re-run effect when password changes


  // --- Leaflet (OpenStreetMap) Integration Logic ---

  // Effect to dynamically load Leaflet CSS and JS files
  useEffect(() => {
    // Check if Leaflet CSS is already in the document head
    if (!document.querySelector('link[href*="leaflet.css"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      link.integrity = 'sha256-p4NxAo9TxxGgCCSgPropynS9kSqyFastalU8PkUWfmkz/tdwG62/rqQkFFMlK/RTgsqT4A2jW/CntN9C7A5VfCg==';
      link.crossOrigin = '';
      document.head.appendChild(link);
    }

    // Check if Leaflet JS is already loaded or being loaded
    if (!window.L && !document.querySelector('script[src*="leaflet.js"]')) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
      script.crossOrigin = '';
      script.async = true;
      script.onload = () => {
        setLeafletLoaded(true);
      };
      script.onerror = () => {
        showToast("Failed to load map library script.", "error");
        setLeafletLoaded(false);
      };
      document.head.appendChild(script);
    } else if (window.L) {
      setLeafletLoaded(true);
    }
  }, []);

  // Function to perform reverse geocoding using Nominatim (OpenStreetMap's geocoding service)
  const reverseGeocodeNominatim = async (lat, lon) => {
    try {
      const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`,
          {
            headers: {
              // IMPORTANT: A User-Agent is required by Nominatim's usage policy.
              // Replace with your actual application name and contact email.
              'User-Agent': 'GrocerySellerRegistrationApp/1.0 (your.email@example.com)'
            }
          }
      );

      if (response.ok) {
        const data = await response.json();
        // Return the full display name or fallback to coordinates if not found
        return data.display_name || `Lat: ${lat.toFixed(6)}, Lng: ${lon.toFixed(6)}`;
      } else {
        console.error("Nominatim reverse geocoding failed (status:", response.status, "). Check User-Agent and network.", response.statusText);
        showToast("Address lookup failed. Coordinates captured.", "error");
        return `Lat: ${lat.toFixed(6)}, Lng: ${lon.toFixed(6)}`; // Fallback to coordinates
      }
    } catch (error) {
      console.error("Nominatim reverse geocoding network error:", error);
      showToast("Network error during address lookup. Coordinates captured.", "error");
      return `Lat: ${lat.toFixed(6)}, Lng: ${lon.toFixed(6)}`; // Fallback to coordinates on network error
    }
  };

  // Function to initialize and render the Leaflet map
  const initializeLeafletMap = async () => {
    // Ensure Leaflet library is loaded and the map container ref is available
    if (!leafletLoaded || !window.L || !mapRef.current) {
      console.warn("Leaflet library not loaded or mapRef not available. Cannot initialize map.");
      return;
    }

    // Destroy any existing map instance to prevent memory leaks and re-initialization issues
    if (leafletMapInstance.current) {
      leafletMapInstance.current.remove(); // Remove the map from the DOM and free resources
      leafletMapInstance.current = null;
    }

    // Default center for the map (e.g., center of India)
    const defaultCenter = { lat: 20.5937, lng: 78.9629 };
    // Determine the initial map center: use existing form coordinates or a default
    let initialLat = parseFloat(formData.latitude);
    let initialLng = parseFloat(formData.longitude);
    let center = (initialLat && initialLng && !isNaN(initialLat) && !isNaN(initialLng))
        ? [initialLat, initialLng]
        : [defaultCenter.lat, defaultCenter.lng];

    // Create a new Leaflet map instance, setting the view to the determined center and zoom level
    const map = window.L.map(mapRef.current).setView(center, 15);
    leafletMapInstance.current = map; // Store the map instance in a ref

    // Add OpenStreetMap tile layer to the map
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Create a draggable marker at the initial center and add it to the map
    const marker = window.L.marker(center, { draggable: true }).addTo(map);
    leafletMarkerInstance.current = marker; // Store the marker instance in a ref

    // Helper function to update form data with new coordinates and reverse geocode for address
    const updateLocationAndAddress = async (latlng) => {
      setFormData(prev => ({ ...prev, latitude: latlng.lat.toString(), longitude: latlng.lng.toString() }));
      const address = await reverseGeocodeNominatim(latlng.lat, latlng.lng);
      setFormData(prev => ({ ...prev, address: address }));
      showToast("Location selected from map!", "success");
    };

    // Perform an initial update based on the marker's starting position
    await updateLocationAndAddress(marker.getLatLng());

    // Add event listener for when the marker is dragged and released
    marker.on('dragend', async (event) => {
      await updateLocationAndAddress(event.target.getLatLng());
    });

    // Add event listener for when the map is clicked (moves marker and updates location)
    map.on('click', async (event) => {
      marker.setLatLng(event.latlng); // Move marker to the clicked location
      await updateLocationAndAddress(event.latlng); // Update form data with new coordinates and address
    });
  };

  // Effect to trigger map initialization when the map container becomes visible and Leaflet is loaded
  useEffect(() => {
    if (showMap && leafletLoaded) {
      initializeLeafletMap();
    }

    // Cleanup function: destroy the map instance when the component unmounts or map is hidden
    return () => {
      if (leafletMapInstance.current) {
        leafletMapInstance.current.remove(); // Remove the map from the DOM and free resources
        leafletMapInstance.current = null;
      }
    };
  }, [showMap, leafletLoaded]); // Re-run effect when showMap or leafletLoaded state changes

  // Function to handle "Choose on Map" button click
  const openMapPicker = () => {
    setLocationLoading(true); // Show loading indicator
    setShowMap(true); // Make the map container visible
    // A small delay to allow the loading spinner to show before the map might appear
    setTimeout(() => setLocationLoading(false), 500);
  };

  // Function to get current geolocation using browser's Geolocation API
  const getCurrentLocation = () => {
    setLocationLoading(true);
    if (!navigator.geolocation) {
      showToast("Geolocation is not supported by this browser.", "error");
      setLocationLoading(false);
      return;
    }

    // Get current position
    navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          // Reverse geocode the obtained coordinates to get a readable address
          const address = await reverseGeocodeNominatim(latitude, longitude);

          // Update form data with the current location and address
          setFormData(prev => ({
            ...prev,
            latitude: latitude.toString(),
            longitude: longitude.toString(),
            address: address
          }));
          showToast("Current location detected successfully!", "success");
          setLocationLoading(false);
        },
        (error) => {
          console.error("Geolocation error:", {
            code: error.code,
            message: error.message
          });
          let errorMessage = "Unable to retrieve your location. Please enter manually or try map selection.";
          if (error.code === error.PERMISSION_DENIED) {
            errorMessage = "Location access denied. Please allow location permissions in your browser settings.";
          } else if (error.code === error.POSITION_UNAVAILABLE) {
            errorMessage = "Location information is unavailable. Check your device's GPS or network.";
          } else if (error.code === error.TIMEOUT) {
            errorMessage = "Location request timed out. Please try again or enter manually.";
          }
          showToast(errorMessage, "error");
          setLocationLoading(false);
        },
        // Geolocation options for better accuracy and timeout
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  // --- Form Validation Logic ---
  const validateStep = (step) => {
    const newErrors = {};
    let isValid = true;

    switch (step) {
      case 1: // Personal Information Step Validation
        if (!formData.name.trim() || formData.name.length < 2) {
          newErrors.name = "Full name is required and must be at least 2 characters.";
          isValid = false;
        }
        if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) {
          newErrors.email = "A valid email address is required.";
          isValid = false;
        }
        if (!formData.phone.trim() || !/^\d{10}$/.test(formData.phone)) {
          newErrors.phone = "A valid 10-digit phone number is required.";
          isValid = false;
        }
        break;
      case 2: // Business Location Step Validation
        if (!formData.address.trim()) {
          newErrors.address = "Business address is required.";
          isValid = false;
        }
        // Validate that latitude and longitude are set and are valid numbers
        if (isNaN(parseFloat(formData.latitude)) || isNaN(parseFloat(formData.longitude)) || !formData.latitude || !formData.longitude) {
          newErrors.location = "Location coordinates are required. Please use 'Current Location' or 'Choose on Map'.";
          isValid = false;
        }
        break;
      case 3: // Security Step Validation
        if (!formData.password || formData.password.length < 6) {
          newErrors.password = "Password must be at least 6 characters long.";
          isValid = false;
        }
        if (formData.password !== formData.confirmPassword) {
          newErrors.confirmPassword = "Passwords do not match.";
          isValid = false;
        }
        break;
      default:
        break;
    }
    setErrors(newErrors); // Update the errors state
    return isValid; // Return overall validation status
  };

  // --- Multi-step Form Navigation Handlers ---

  // Handle navigation to the next step
  const handleNextStep = (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1); // Increment current step if validation passes
    } else {
      showToast("Please complete the required information.", "error"); // Updated message
    }
  };

  // Handle navigation to the previous step
  const handlePreviousStep = () => {
    setCurrentStep(prev => prev - 1); // Decrement current step
  };

  // --- Form Submission and OTP Verification Handlers ---

  // Handle the final registration submission (API call)
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission

    if (!validateStep(3)) { // Validate the final step (Security) before submission
      showToast("Please complete the required information.", "error"); // Updated message
      return;
    }

    setIsLoading(true); // Show loading indicator

    try {
      // Prepare registration data
      const registrationData = {
        name: formData.name.trim(),
        email: formData.email.toLowerCase().trim(),
        phone: formData.phone,
        password: formData.password,
        role: "seller", // Hardcoded role for seller registration
        gender: formData.gender || undefined, // Optional fields
        date_of_birth: formData.date_of_birth || undefined, // Optional fields
        address: formData.address.trim(),
        latitude: parseFloat(formData.latitude),
        longitude: parseFloat(formData.longitude)
      };

      // API call to register the seller
      const response = await fetch('http://localhost:3000/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(registrationData)
      });

      const data = await response.json();

      if (data.success) {
        showToast("OTP sent to your email! Please check your inbox!", "success");
        setCurrentStep(4); // Move to OTP verification step on successful registration
      } else {
        showToast(data.message || "Registration failed. Please try again.", "error");
      }
    } catch (error) {
      console.error("Registration network error:", error);
      showToast("Network error. Could not connect to server. Please try again.", "error");
    } finally {
      setIsLoading(false); // Hide loading indicator
    }
  };

  // Handle OTP verification submission (API call)
  // Handle OTP verification submission (API call)
  const handleOTPVerification = async (e) => {
    if (e) e.preventDefault(); // Only prevent default if event exists

    if (!otpCode || otpCode.length !== 6) {
      showToast("Please enter a valid 6-digit OTP.", "error");
      return;
    }

    setIsLoading(true); // Show loading indicator

    try {
      // API call to verify OTP
      const response = await fetch('http://localhost:3000/api/auth/verify-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: formData.email.toLowerCase().trim(),
          otp: otpCode,
          type: 'registration', // Specify the type of OTP verification
          role: 'seller' // Specify role for verification
        })
      });

      const data = await response.json();

      if (data.success) {
        showToast("Registration completed successfully! Please sign in.", "success");
        // Store authentication token and user data in local storage
        if (data.data?.token) {
          localStorage.setItem('seller_token', data.data.token);
          localStorage.setItem('seller_user', JSON.stringify(data.data.user));
        }
        // Redirect to seller login page after successful OTP verification
        setTimeout(() => {
          navigate('/seller/login');
        }, 1500); // Small delay to show success message
      } else {
        showToast(data.message || "OTP verification failed. Please check your OTP and try again.", "error");
      }
    } catch (error) {
      console.error("OTP verification network error:", error);
      showToast("Network error. Could not connect to server. Please try again.", "error");
    } finally {
      setIsLoading(false); // Hide loading indicator
    }
  };

  // --- Render content for each step of the form ---
  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-800 flex items-center">
                <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">1</div>
                Personal Information
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="fullName" className="text-sm font-semibold text-gray-700">Full Name *</label>
                  <input
                      id="fullName"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-0 ${
                          errors.name
                              ? 'border-red-300 focus:border-red-500 bg-red-50'
                              : 'border-gray-200 focus:border-green-500 bg-white hover:border-green-300'
                      }`}
                  />
                  {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                </div>

                <div className="space-y-2">
                  <label htmlFor="phoneNumber" className="text-sm font-semibold text-gray-700">Phone Number *</label>
                  <input
                      id="phoneNumber"
                      type="tel"
                      placeholder="10-digit phone number"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-0 ${
                          errors.phone
                              ? 'border-red-300 focus:border-red-500 bg-red-50'
                              : 'border-gray-200 focus:border-green-500 bg-white hover:border-green-300'
                      }`}
                  />
                  {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="emailAddress" className="text-sm font-semibold text-gray-700">Email Address *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                      id="emailAddress"
                      type="email"
                      placeholder="Enter your email address"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className={`w-full pl-12 pr-4 py-3 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-0 ${
                          errors.email
                              ? 'border-red-300 focus:border-red-500 bg-red-50'
                              : 'border-gray-200 focus:border-green-500 bg-white hover:border-green-300'
                      }`}
                  />
                </div>
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="gender" className="text-sm font-semibold text-gray-700">Gender</label>
                  <select
                      id="gender"
                      value={formData.gender}
                      onChange={(e) => handleInputChange("gender", e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 bg-white hover:border-green-300 transition-all duration-300 focus:outline-none focus:ring-0"
                  >
                    <option value="">Select gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label htmlFor="dob" className="text-sm font-semibold text-gray-700">Date of Birth</label>
                  <input
                      id="dob"
                      type="date"
                      value={formData.date_of_birth}
                      onChange={(e) => handleInputChange("date_of_birth", e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-green-500 bg-white hover:border-green-300 transition-all duration-300 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>
            </div>
        );
      case 2:
        return (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-800 flex items-center">
                <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">2</div>
                Business Location
              </h3>

              <div className="space-y-4">
                <div className="flex flex-wrap gap-3">
                  <button
                      type="button"
                      onClick={getCurrentLocation}
                      disabled={locationLoading}
                      className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 ${
                          locationLoading && !showMap // Show spinner only for current location when map is not active
                              ? 'bg-gray-200 text-gray-700 cursor-not-allowed'
                              : 'bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-emerald-600 hover:to-green-600'
                      }`}
                  >
                    {locationLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
                    <span>Use Current Location</span>
                  </button>

                  <button
                      type="button"
                      onClick={openMapPicker}
                      disabled={locationLoading && showMap} // Disable if map is already loading/shown
                      className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 ${
                          showMap
                              ? 'bg-green-50 border-2 border-green-500 text-green-700 cursor-default' // Style when map is active
                              : 'bg-white border-2 border-green-500 text-green-600 hover:bg-green-50'
                      }`}
                  >
                    {locationLoading && showMap ? <Loader2 className="w-4 h-4 animate-spin" /> : <Map className="w-4 h-4" />}
                    <span>Choose on Map</span>
                  </button>
                </div>

                {errors.location && <p className="text-red-500 text-sm mt-1">{errors.location}</p>}
              </div>

              {/* Map Container */}
              {showMap && (
                  <div className="mb-4 border-2 border-gray-200 rounded-xl overflow-hidden shadow-md">
                    {leafletLoaded ? (
                        <div ref={mapRef} className="w-full h-80 md:h-96"></div>
                    ) : (
                        <div className="w-full h-80 md:h-96 flex items-center justify-center bg-gray-100 text-gray-500">
                          <Loader2 className="w-8 h-8 animate-spin mr-2" />
                          Loading Map...
                        </div>
                    )}
                  </div>
              )}

              <div className="space-y-2">
                <label htmlFor="businessAddress" className="text-sm font-semibold text-gray-700">Business Address *</label>
                <textarea
                    id="businessAddress"
                    placeholder="Enter your complete business address"
                    value={formData.address}
                    onChange={(e) => handleInputChange("address", e.target.value)}
                    rows="3"
                    className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-0 resize-none ${
                        errors.address
                            ? 'border-red-300 focus:border-red-500 bg-red-50'
                            : 'border-gray-200 focus:border-green-500 bg-white hover:border-green-300'
                    }`}
                />
                {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address}</p>}
              </div>

              {(formData.latitude && formData.longitude) && (
                  <div className="p-4 bg-green-50 rounded-xl border border-green-200 flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                    <p className="text-sm text-green-700">
                      <strong>Coordinates:</strong> {parseFloat(formData.latitude).toFixed(6)}, {parseFloat(formData.longitude).toFixed(6)}
                    </p>
                  </div>
              )}
            </div>
        );
      case 3:
        return (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-800 flex items-center">
                <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">3</div>
                Security
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="password" className="text-sm font-semibold text-gray-700">Password *</label>
                  <div className="relative">
                    <input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Create a strong password"
                        value={formData.password}
                        onChange={(e) => handleInputChange("password", e.target.value)}
                        className={`w-full px-4 py-3 pr-12 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-0 ${
                            errors.password
                                ? 'border-red-300 focus:border-red-500 bg-red-50'
                                : 'border-gray-200 focus:border-green-500 bg-white hover:border-green-300'
                        }`}
                    />
                    <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
                        aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}

                  {/* LLM-powered Password Strength Feedback */}
                  {isCheckingPassword && formData.password.length > 0 && (
                      <p className="text-gray-500 text-sm mt-1 flex items-center">
                        <Loader2 className="w-4 h-4 animate-spin mr-1" /> Checking strength...
                      </p>
                  )}
                  {!isCheckingPassword && formData.password.length > 0 && passwordStrength.rating && (
                      <div className="mt-2 text-sm">
                        <p className={`font-semibold ${
                            passwordStrength.rating === 'strong' ? 'text-green-600' :
                                passwordStrength.rating === 'medium' ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          Password Strength: {passwordStrength.rating.charAt(0).toUpperCase() + passwordStrength.rating.slice(1)}
                        </p>
                        {passwordStrength.tip && <p className="text-gray-600">{passwordStrength.tip}</p>}
                      </div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="confirmPassword" className="text-sm font-semibold text-gray-700">Confirm Password *</label>
                  <div className="relative">
                    <input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Confirm your password"
                        value={formData.confirmPassword}
                        onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                        className={`w-full px-4 py-3 pr-12 rounded-xl border-2 transition-all duration-300 focus:outline-none focus:ring-0 ${
                            errors.confirmPassword
                                ? 'border-red-300 focus:border-red-500 bg-red-50'
                                : 'border-gray-200 focus:border-green-500 bg-white hover:border-green-300'
                        }`}
                    />
                    <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
                        aria-label={showConfirmPassword ? "Hide confirm password" : "Show confirm password"}
                    >
                      {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>}
                </div>
              </div>
            </div>
        );
      case 4: // OTP Verification step
        return (
            <div className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/30 overflow-hidden max-w-md mx-auto p-8">
              <div className="relative bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 p-8 text-center rounded-2xl mb-8">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Verify Your Email</h2>
                <p className="text-green-100">Enter the 6-digit code sent to your email</p>
              </div>

              {/* Separate form for OTP verification - NOT nested inside the main form */}
              <div className="space-y-6">
                <div className="space-y-2 text-center">
                  <label htmlFor="otpCode" className="text-sm font-semibold text-gray-700">Verification Code</label>
                  <input
                      id="otpCode"
                      type="text"
                      placeholder="000000"
                      value={otpCode}
                      // Restrict input to 6 digits and numbers only
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      className="w-full px-4 py-4 text-center text-2xl font-bold tracking-widest rounded-xl border-2 border-gray-200 focus:border-green-500 bg-white hover:border-green-300 transition-all duration-300 focus:outline-none focus:ring-0"
                      maxLength="6"
                      inputMode="numeric" // Hint for mobile keyboards
                      pattern="\d{6}" // HTML5 pattern validation
                  />
                </div>

                <button
                    type="button" // Changed from "submit" to "button"
                    onClick={handleOTPVerification} // Direct onClick handler
                    disabled={isLoading || otpCode.length !== 6} // Disable if loading or OTP not 6 digits
                    className="w-full py-4 bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 text-white font-bold text-lg rounded-xl hover:from-teal-600 hover:via-emerald-600 hover:to-green-600 transition-all duration-300 shadow-xl hover:shadow-2xl disabled:opacity-50 transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  {isLoading ? (
                      <div className="flex items-center justify-center space-x-2">
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Verifying...</span>
                      </div>
                  ) : (
                      "Verify & Complete Registration"
                  )}
                </button>

                <div className="text-center">
                  <button
                      type="button"
                      onClick={() => navigate('/seller/login')} // Redirect to login, not back to step 1
                      className="text-gray-600 hover:text-gray-800 text-sm underline"
                  >
                    Proceed to Sign In
                  </button>
                </div>
              </div>
            </div>
        );
      default:
        return null;
    }
  };


  return (
      // Main container for the registration page, with full height and a gradient background
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4 sm:p-6 lg:p-8 font-['Inter']">
        {/* Subtle background SVG pattern */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
          <svg className="w-full h-full" viewBox="0 0 800 600" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="100" cy="50" r="80" fill="currentColor" className="text-green-300 opacity-50" />
            <circle cx="700" cy="150" r="120" fill="currentColor" className="text-emerald-300 opacity-40" />
            <circle cx="250" cy="400" r="90" fill="currentColor" className="text-green-200 opacity-60" />
            <circle cx="550" cy="550" r="100" fill="currentColor" className="text-emerald-200 opacity-50" />
            <path d="M50 250 Q150 150 250 250 T450 250 T650 250" stroke="currentColor" strokeWidth="2" className="text-green-300 opacity-30" />
            <path d="M750 300 Q650 400 550 300 T350 300 T150 300" stroke="currentColor" strokeWidth="2" className="text-emerald-300 opacity-20" />
          </svg>
        </div>


        {/* Toast Notification */}
        {toast.show && (
            <div
                className={`fixed top-5 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3 transition-all duration-300 ease-out
            ${toast.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"}`}
            >
              {toast.type === "success" ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              <span className="font-semibold">{toast.message}</span>
            </div>
        )}

        {/* Main registration card container - now a flex container for two halves */}
        <div className="w-full max-w-5xl bg-white/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/30 overflow-hidden my-8 flex flex-col md:flex-row z-10"> {/* Added z-10 to keep form above background */}

          {/* Left Half: Reactive Image Animation */}
          <div className="relative flex-1 hidden md:flex items-center justify-center p-8 bg-gradient-to-br from-emerald-500 to-green-600 rounded-l-3xl overflow-hidden">
            {/* Abstract pulsating background circles */}
            <div className="absolute inset-0 z-0 flex items-center justify-center">
              <div className="relative w-64 h-64 bg-white/10 rounded-full animate-pulse top-1/4 left-1/4"></div>
              <div className="absolute w-96 h-96 bg-white/5 rounded-full animate-pulse-slow bottom-1/3 right-1/4"></div>
              <div className="absolute w-48 h-48 bg-white/15 rounded-full animate-pulse-delay top-1/2 left-1/3"></div>
            </div>
            {/* Main SVG illustration: Shopping Cart */}
            <div className="relative z-10 text-white text-center flex flex-col items-center">
              <ShoppingCart className="w-40 h-40 md:w-56 md:h-56 animate-bounce-subtle" /> {/* Lucide icon directly */}
              <h2 className="text-4xl font-extrabold mb-4 text-shadow-lg">Empower Your Business</h2>
              <p className="text-xl opacity-90 leading-relaxed max-w-sm">Join our platform and connect with thousands of customers looking for fresh, local products. Grow with us!</p>
            </div>
          </div>

          {/* Right Half: Form Content */}
          <div className="w-full md:w-1/2 p-4 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                {/* "Back to Home" link */}
                <button
                    onClick={() => navigate('/')}
                    className="flex items-center text-gray-600 hover:text-gray-800 transition-colors duration-200 font-semibold text-sm"
                >
                  <Home className="w-4 h-4 mr-1" />
                  Home
                </button>
                {/* "Already have an account?" link */}
                {currentStep !== 4 && (
                    <p className="text-sm text-gray-600">
                      Already have an account?{" "}
                      <button
                          onClick={() => navigate('/seller/login')}
                          className="text-green-600 hover:text-green-800 font-semibold transition-colors duration-200"
                      >
                        Sign In
                      </button>
                    </p>
                )}
              </div>

              {currentStep !== 4 && ( // Hide header and progress for OTP step as it has its own
                  <>
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-6 text-center md:text-left">
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-emerald-700">
                    Register as a Seller
                  </span>
                    </h1>

                    {/* Step progress indicators */}
                    <div className="flex justify-between items-center mb-6 relative px-5">
                      {/* Lines removed as requested */}

                      {[1, 2, 3].map((step) => (
                          <div key={step} className="flex-1 flex flex-col items-center z-10"> {/* z-10 to keep circles above line */}
                            <div
                                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white transition-all duration-300 ease-in-out
                          ${currentStep === step
                                    ? 'bg-gradient-to-r from-green-500 to-emerald-600 shadow-md transform scale-110 ring-4 ring-offset-2 ring-emerald-400' // Increased ring size for more glow
                                    : currentStep > step
                                        ? 'bg-green-400 opacity-70'
                                        : 'bg-gray-300'
                                }`}
                            >
                              {step === 1 && <User className="w-5 h-5" />}
                              {step === 2 && <MapPin className="w-5 h-5" />}
                              {step === 3 && <KeyRound className="w-5 h-5" />}
                            </div>
                            <p
                                className={`text-sm mt-2 font-medium transition-colors duration-300 text-center
                          ${currentStep === step ? 'text-green-700' : 'text-gray-500'}`}
                            >
                              {step === 1 ? "Personal" : step === 2 ? "Location" : "Security"}
                            </p>
                          </div>
                      ))}
                    </div>
                  </>
              )}

              <form onSubmit={(currentStep === 3) ? handleSubmit : handleNextStep} className="pt-4">
                {renderStepContent()}

                {/* Navigation buttons for multi-step form */}
                {currentStep !== 4 && ( // Hide navigation buttons on OTP step
                    <div className="mt-8 flex justify-between items-center">
                      {/* Previous Step Button */}
                      {currentStep > 1 && (
                          <button
                              type="button"
                              onClick={handlePreviousStep}
                              className="px-6 py-3 bg-gray-200 text-gray-700 font-bold rounded-xl shadow-md hover:shadow-lg hover:bg-gray-300 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] flex items-center"
                          >
                            <ArrowLeft className="w-5 h-5 mr-2" />
                            Back
                          </button>
                      )}
                      {/* Next Step / Register Now Button */}
                      {currentStep < 3 && (
                          <button
                              type="submit" // This button will trigger handleNextStep via form onSubmit
                              className={`ml-auto px-8 py-3 bg-gradient-to-r from-green-600 to-emerald-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:from-emerald-700 hover:to-green-600 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] flex items-center
                        ${currentStep === 1 ? 'w-full md:w-auto' : ''}`}
                              disabled={isLoading}
                          >
                            {isLoading ? (
                                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                            ) : (
                                <>
                                  Next Step <ArrowRight className="w-5 h-5 ml-2" />
                                </>
                            )}
                          </button>
                      )}

                      {currentStep === 3 && (
                          <button
                              type="submit" // This button will trigger handleSubmit via form onSubmit
                              className="ml-auto px-8 py-3 bg-gradient-to-r from-green-600 to-emerald-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:from-emerald-700 hover:to-green-600 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] flex items-center"
                              disabled={isLoading}
                          >
                            {isLoading ? (
                                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                            ) : (
                                "Register Now"
                            )}
                          </button>
                      )}
                    </div>
                )}
              </form>
            </div>
          </div>
        </div>
        {/* Tailwind CSS CDN script (for standalone immersive) */}
        <script src="https://cdn.tailwindcss.com"></script>
        {/* Custom CSS for subtle animations */}
        <style>
          {`
        .animate-bounce-subtle {
          animation: bounce-subtle 4s infinite ease-in-out;
        }
        @keyframes bounce-subtle {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-5px);
          }
        }

        .animate-pulse-slow {
            animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        .animate-pulse-delay {
            animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite 1s; /* Start 1s later */
        }
        .text-shadow-lg {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }
        `}
        </style>
      </div>
  );
};

// The main component exported is now SellerRegisterContent, suitable for direct use
// within your application's existing BrowserRouter setup.
export default SellerRegister;
