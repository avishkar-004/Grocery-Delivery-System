import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom"; // Import Link
import { ShoppingCart, User, Store, Star, ArrowRight, Users, Package, TrendingUp, CheckCircle, Zap, Heart, Award } from "lucide-react";

const Hero = () => {
  const [activeCard, setActiveCard] = useState(null);
  const [scrollY, setScrollY] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    const handleMouseMove = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const stats = [
    { icon: Users, value: '50K+', label: 'Active Users' },
    { icon: Store, value: '1.2K+', label: 'Verified Sellers' },
    { icon: Package, value: '100K+', label: 'Products' },
    { icon: TrendingUp, value: '99.9%', label: 'Uptime' }
  ];

  const features = [
    { icon: Zap, title: 'Lightning Fast', desc: 'Get groceries in 30 minutes' },
    { icon: CheckCircle, title: 'Quality Assured', desc: 'Fresh products guaranteed' },
    { icon: Heart, title: 'Customer Love', desc: '4.9/5 rating from users' },
    { icon: Award, title: 'Best Prices', desc: 'Competitive marketplace rates' }
  ];

  return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 overflow-hidden relative"> {/* Added relative to allow absolute children */}
        {/* Dynamic Background Elements */}
        <div className="absolute inset-0 pointer-events-none"> {/* Added pointer-events-none to prevent interfering with interactions */}
          {/* Animated gradient orbs */}
          <div
              className="absolute w-96 h-96 bg-gradient-to-r from-emerald-400/20 to-blue-500/20 rounded-full mix-blend-multiply filter blur-xl animate-pulse"
              style={{
                left: `${mousePosition.x * 0.02}px`, // Use template literals for pixel values
                top: `${mousePosition.y * 0.02}px`,
                transform: `translate(-50%, -50%) scale(${1 + scrollY * 0.001})`
              }}
          />
          <div
              className="absolute w-72 h-72 bg-gradient-to-r from-yellow-400/20 to-pink-500/20 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-1000"
              style={{
                right: `${mousePosition.x * -0.015}px`, // Adjusted for right side
                bottom: `${mousePosition.y * -0.015}px`, // Adjusted for bottom side
                transform: `translate(50%, 50%) scale(${1 + scrollY * 0.0008})`
              }}
          />

          {/* Floating geometric shapes */}
          {[...Array(12)].map((_, i) => (
              <div
                  key={i}
                  className={`absolute opacity-30 ${
                      i % 3 === 0 ? 'bg-emerald-300' : i % 3 === 1 ? 'bg-blue-300' : 'bg-yellow-300'
                  } ${
                      i % 4 === 0 ? 'rounded-full' : i % 4 === 1 ? 'rounded-lg rotate-45' : 'rounded-xl'
                  }`}
                  style={{
                    width: `${Math.random() * 20 + 10}px`, // Use template literals for pixel values
                    height: `${Math.random() * 20 + 10}px`,
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    animationDelay: `${Math.random() * 5}s`,
                    animation: `float ${3 + Math.random() * 4}s ease-in-out infinite alternate`
                  }}
              />
          ))}
        </div>

        {/* Main Content */}
        <div className="relative z-10 container mx-auto px-4 py-8">
          {/* Header Section */}
          <div className="text-center mb-12"> {/* Increased bottom margin for header */}
            <div className="inline-flex items-center space-x-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm px-4 py-2 rounded-full border border-emerald-200 dark:border-gray-600 mb-6 animate-fade-in">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Rated #1 Grocery Platform</span>
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-4 leading-tight">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 animate-gradient-x">
              Fresh
            </span>
              <span className="text-gray-800 dark:text-white">Market</span>
            </h1>

            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto"> {/* Increased bottom margin */}
              🥬 **Premium Quality** • 🚀 **Lightning Delivery** • 💰 **Best Prices** • 🌟 **Trusted by Thousands**
            </p>

            {/* Stats Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-12"> {/* Increased bottom margin */}
              {stats.map((stat, index) => (
                  <div key={index} className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-2xl p-4 border border-gray-200 dark:border-gray-700 hover:scale-105 transition-all duration-300 hover:shadow-lg">
                    <stat.icon className="w-6 h-6 text-emerald-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-800 dark:text-white">{stat.value}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</div>
                  </div>
              ))}
            </div>
          </div>

          {/* Main Cards Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12"> {/* Increased bottom margin */}
            {/* Buyer Card */}
            <div
                className={`relative p-6 rounded-3xl bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/30 dark:to-blue-800/30 border-2 border-blue-200 dark:border-blue-700 hover:border-blue-400 dark:hover:border-blue-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/25 group cursor-pointer ${
                    activeCard === 'buyer' ? 'scale-105 shadow-2xl shadow-blue-500/25' : ''
                }`}
                onMouseEnter={() => setActiveCard('buyer')}
                onMouseLeave={() => setActiveCard(null)}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="relative z-10">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:rotate-12 transition-transform duration-300 shadow-lg">
                  <ShoppingCart className="h-8 w-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 text-center">For Buyers</h3>

                <div className="space-y-2 mb-6">
                  {['Browse 100K+ fresh products', '24/7 customer support'].map((feature, i) => (
                      <div key={i} className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                  ))}
                </div>

                <div className="space-y-3">
                  {/* Corrected Link usage: Button is a child of Link */}
                  <Link to="/buyer/login" className="block">
                    <button className="w-full bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 flex items-center justify-center space-x-2 group">
                      <span>Login as Buyer</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </Link>
                  {/* Corrected Link usage */}
                  <Link to="/buyer/register" className="block">
                    <button className="w-full border-2 border-blue-500 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105">
                      Register as Buyer
                    </button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Seller Card */}
            <div
                className={`relative p-6 rounded-3xl bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/30 dark:to-emerald-800/30 border-2 border-emerald-200 dark:border-emerald-700 hover:border-emerald-400 dark:hover:border-emerald-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-emerald-500/25 group cursor-pointer ${
                    activeCard === 'seller' ? 'scale-105 shadow-2xl shadow-emerald-500/25' : ''
                }`}
                onMouseEnter={() => setActiveCard('seller')}
                onMouseLeave={() => setActiveCard(null)}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="relative z-10">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:rotate-12 transition-transform duration-300 shadow-lg">
                  <Store className="h-8 w-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 text-center">For Sellers</h3>

                <div className="space-y-2 mb-6">
                  {['Reach 50K+ active buyers', 'Easy inventory management', 'Real-time analytics', 'Low commission rates'].map((feature, i) => (
                      <div key={i} className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                  ))}
                </div>

                <div className="space-y-3">
                  {/* Corrected Link usage */}
                  <Link to="/seller/login" className="block">
                    <button className="w-full bg-gradient-to-r from-emerald-500 to-emerald-700 hover:from-emerald-600 hover:to-emerald-800 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-emerald-500/50 flex items-center justify-center space-x-2 group">
                      <span>Login as Seller</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </Link>
                  {/* Corrected Link usage */}
                  <Link to="/seller/register" className="block">
                    <button className="w-full border-2 border-emerald-500 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105">
                      Register as Seller
                    </button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Admin Card - Re-added as it was missing from your previous paste */}
            <div
                className={`relative p-6 rounded-3xl bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/30 dark:to-purple-800/30 border-2 border-purple-200 dark:border-purple-700 hover:border-purple-400 dark:hover:border-purple-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25 group cursor-pointer ${
                    activeCard === 'admin' ? 'scale-105 shadow-2xl shadow-purple-500/25' : ''
                }`}
                onMouseEnter={() => setActiveCard('admin')}
                onMouseLeave={() => setActiveCard(null)}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="relative z-10">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:rotate-12 transition-transform duration-300 shadow-lg">
                  <User className="h-8 w-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 text-center">Administration</h3>

                <div className="space-y-2 mb-6">
                  {['Manage platform operations', 'Oversee all transactions', 'Ensure marketplace quality', 'User & seller moderation'].map((feature, i) => (
                      <div key={i} className="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                  ))}
                </div>

                <div className="space-y-3">
                  {/* Corrected Link usage */}
                  <Link to="/admin/login" className="block">
                    <button className="w-full bg-gradient-to-r from-purple-500 to-purple-700 hover:from-purple-600 hover:to-purple-800 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-purple-500/50 flex items-center justify-center space-x-2 group">
                      <span>Admin Access</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"> {/* Increased bottom margin */}
            {features.map((feature, index) => (
                <div key={index} className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-2xl p-4 border border-gray-200 dark:border-gray-700 hover:scale-105 transition-all duration-300 hover:shadow-lg text-center group">
                  <feature.icon className="w-8 h-8 text-emerald-600 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                  <h4 className="font-semibold text-gray-800 dark:text-white mb-1">{feature.title}</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">{feature.desc}</p>
                </div>
            ))}
          </div>

          {/* CTA Section */}
          <div className="text-center bg-gradient-to-r from-emerald-500 to-blue-600 rounded-3xl p-8 text-white">
            <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Grocery Experience?</h2>
            <p className="text-lg mb-6 opacity-90">Join thousands of satisfied customers and sellers today</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <button className="bg-white text-emerald-600 hover:bg-gray-100 font-semibold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2">
                <span>Get Started Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              {/* Added Link for Learn More button as well */}
              <Link to="/learn-more">
                <button className="border-2 border-white text-white hover:bg-white hover:text-emerald-600 font-semibold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-105">
                  Learn More
                </button>
              </Link>
            </div>
          </div>
        </div>

        {/* Global styles block - moved out of line as it's better placed in a CSS file or a dedicated style tag if using styled-jsx */}
        <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        
        .animate-gradient-x {
          background-size: 200% 200%;
          animation: gradient-x 3s ease infinite;
        }
        
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
      `}</style>
      </div>
  );
};

export default Hero;